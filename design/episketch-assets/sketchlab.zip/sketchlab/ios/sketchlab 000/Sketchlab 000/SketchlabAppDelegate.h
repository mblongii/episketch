//
//  SketchlabAppDelegate.h
//  Sketchlab 000
//
//  Created by Mike Long on 10/21/13.
//  Copyright (c) 2013 Mike Long. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SketchlabAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
