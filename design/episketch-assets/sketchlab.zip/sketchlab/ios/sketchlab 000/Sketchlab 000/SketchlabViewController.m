//
//  SketchlabViewController.m
//  Sketchlab 000
//
//  Created by Mike Long on 10/21/13.
//  Copyright (c) 2013 Mike Long. All rights reserved.
//

#import "SketchlabViewController.h"

@interface SketchlabViewController ()

@end

@implementation SketchlabViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
