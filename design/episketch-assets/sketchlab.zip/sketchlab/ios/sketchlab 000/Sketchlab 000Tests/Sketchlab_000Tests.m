//
//  Sketchlab_000Tests.m
//  Sketchlab 000Tests
//
//  Created by Mike Long on 10/21/13.
//  Copyright (c) 2013 Mike Long. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Sketchlab_000Tests : XCTestCase

@end

@implementation Sketchlab_000Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
